Xfce, Whisker panel (category icon size small)

Favorites icon		= user-bookmarks

Recently Used icon	= default-folder-recent

All Applications icon	= applications-all
