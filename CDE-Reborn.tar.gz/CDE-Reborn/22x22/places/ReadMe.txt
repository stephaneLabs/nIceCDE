SpaceFM, left panel (== 'bookmarks panel')

Bookmarks icon	= gtk-directory

All other icons	= user-bookmarks
