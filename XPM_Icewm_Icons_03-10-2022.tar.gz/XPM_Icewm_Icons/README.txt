XPM Icon set made from CDE desktop environment XPM icons, in order to complete the icewm menu part that is distribution dependent
(for example a debian menu included in the icewm menu) and some buttons like the exit button, or lock screen button.

These XPM icons are to be put in your ~/.icewm/icons directory.
