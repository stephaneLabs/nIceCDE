/* XPM */
/* $XConsortium: Fpmin.l.pm /main/3 1995/07/18 17:00:16 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * minimize [] = {
/* width height ncolors cpp [x_hot y_hot] */
"21 14 3 1 0 0",
/* colors */
"     s bottomShadowColor m black c #636363636363",
".    s topShadowColor m white c #bdbdbdbdbdbd",
"X    s background    m black c #949494949494",
/* pixels */
" ....................",
" .XXXXXXXXXXXXXXXXXX ",
" .XXXXXXXXXXXXXXXXXX ",
" .XXXXXXXXXXXXXXXXXX ",
" .XXXXXXXXXXXXXXXXXX ",
" .XXXXXXX... XXXXXXX ",
" .XXXXXXX.XX XXXXXXX ",
" .XXXXXXX.XX XXXXXXX ",
" .XXXXXXX.   XXXXXXX ",
" .XXXXXXXXXXXXXXXXXX ",
" .XXXXXXXXXXXXXXXXXX ",
" .XXXXXXXXXXXXXXXXXX ",
" .XXXXXXXXXXXXXXXXXX ",
" .                   "};
